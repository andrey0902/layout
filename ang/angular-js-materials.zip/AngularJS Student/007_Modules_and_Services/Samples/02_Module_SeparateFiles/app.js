﻿// Создание нового модуля exampleApp
var module = angular.module("exampleApp", []);